/* Doesn't contain good style or quality, necessarily. (or robustness,
 * correctness ... it's basically a hacked up "C script". */

/* Just contains an infinite loop. */

#include <stdio.h>

int main()
{
  while (1)
  {
    printf("here");
  }
  return 0;
}
