// ECE 312 LEC A1
// Assignment 9, Fall 2014
// Author: 
// Student ID: 
// Percent Original: 
// Other Contributors: 

#include <math.h> // For standard C math functions

/* WRITE A COMMENT HEADER HERE IN YOUR OWN WORDS.
*/
int zeroCrossCounter(int input, int thresh) {
	return 0;
}
